//Swift generics - by theabner -
//find me on
// 📸✨ - @abner.abbey |
// 🎥📲: youtube.com/theabner |

import UIKit

// Swift generics in standard library
let intArray = [4, 3, 2, 1]
let stringArray = ["Hola", "Estos", "Son", "Strings"]
let viewsArray = [UIView(), UIView(), UIView()]
var doubleArray = Array<Double>()

let intDictionary = ["1": 1, "2": 2, "3": 3]
let intIntDict = [1: 10, 2: 20, 3: 30]
let stringDict = ["hombre": "Luis", "mujer": "Luisa"]
var aDictionary = Dictionary<String, String>()

//Problematic
func swap(_ a: inout Int, _ b: inout Int) {
    let tempA = a
    a = b
    b = tempA
}

func swap(_ a: inout Float, _ b: inout Float) {
    let tempA = a
    a = b
    b = tempA
}

func swap(_ a: inout Double, _ b: inout Double) {
    let tempA = a
    a = b
    b = tempA
}

func swap(_ a: inout String, _ b: inout String) {
    let tempA = a
    a = b
    b = tempA
}

// Generic type parameters

func genericFunction<T, U>(aParam: T, bParam: U) {
    
}

struct Array<Element> {
    
}

struct Dictionary<Key, Value> {
    
}

enum Result<Success, Error> {
    
}



var a = 5
var b = 12

func swap<T>(_ a: inout T, _ b: inout T) {
    
    let tempA = a
    a = b
    b = tempA
}

print(a, b)
swap(&a, &b)
print(a, b)

var string1 = "Hola"
var string2 = "Mundo"
swap(&string1, &string2)
print(string1, string2)


struct Stack<Element> {
    
    private var items = [Element]()
    
    mutating func push(_ element: Element) {
        items.append(element)
    }
    
    mutating func pop() -> Element? {
        return items.popLast()
    }
    
}

var stack = Stack<Int>()

stack.push(4)
stack.push(6)

print(stack.pop())
print(stack.pop())

var stringStack = Stack<String>()
stringStack.push("Hola")

print(stringStack.pop())






























